import crypto from "crypto";

import Usuario from "./src/models/Usuario";
import Time from "./src/models/Time";
import Jogo from "./src/models/Jogo";
import Rodada from "./src/models/Rodada";
import ApostaRodada from "./src/models/ApostaRodada";
import ApostaJogo, { Palpite } from "./src/models/ApostaJogo";

import JSONApostaRodadasRepository from "./src/repositories/JSONApostaRodadasRepository";
import JSONRodadasRepository from "./src/repositories/JSONRodadasRepository";
import JSONTimesRepository from "./src/repositories/JSONTimesRepository";
import JSONUsuariosRepository from "./src/repositories/JSONUsuariosRepository";
import Calendario from "./src/models/Calendario";

const usuariosRepository = new JSONUsuariosRepository();
const timesRepository = new JSONTimesRepository();
const rodadaRepository = new JSONRodadasRepository();
const apostaRodadaRepository = new JSONApostaRodadasRepository();

//Teste TimeRepository
// const timeTeste = new Time("time qualquer", 1);
// timesRepository.update(timeTeste)
//     .then( (time) => {
//         console.log(JSON.stringify(time, null, 2));
//         return 1;
//     })
// timesRepository.findById(1)
//     .then( (time) => {
//         console.log(JSON.stringify(time, null, 2));
//         return 1;
//     })
// timesRepository.findAll()
//     .then( (time) => {
//         console.log(JSON.stringify(time, null, 2));
//         return 1;
//     })
//     .then(() => {
//         return timesRepository.findAll()
//     })
//     .then((times) => {
//         console.log(JSON.stringify(times, null, 2));
//     })
//     .catch( (erro) => {
//         console.log(`Não foi possível atender a requisição, Motivo: ${erro.message}`)
//     });

//Teste RodadasRepository
// rodadaRepository.findAll()
//     .then((rodadas) => {
//         console.log(JSON.stringify(rodadas[0].getJogos()[0], null, 2));
//     })
// rodadaRepository.findByNumeroRodada(1)
//     .then((rodada) => {
//         console.log(rodada.getJogos()[0]);
//     })
// timesRepository.findAll()
//     .then((times) => {
//         return Calendario.geraCalendarioCampeonato(times, new Date(2021, 4, 23, 16));
//     })
//     .then( (rodadas) => {
//         rodadaRepository.save(rodadas);
//     })
//     .catch((erro: Error) => {
//         console.log(`Não foi possível atender a requisição, Motivo: ${erro.message}`);
//     });

//Teste UsuariosRepository
// const user = new Usuario("arara", "exemplo@email.com", "123456");
// usuariosRepository.findAll()
//     .then((usuarios) => {
//         console.log(usuarios);
//     })
// usuariosRepository.findByEmail("exemplo@email.com")
//     .then((usuario) => {
//         console.log(usuario);
//     })
// usuariosRepository.update(user);
// usuariosRepository.remove("exemplo@email.com");

//TesteApostaRodadaRepository
// const usuario = new Usuario("Erik Bergkamp", "erik@email.com", "69cf2ca04408a449374e392e64cfc4f8f2fb5c3c5b619e48bc3ddf81099e151e");
// const palpites: Palpite[] = [];
// for (let i = 0; i < 10; i++) {
//     palpites.push({
//         golsMandante: 3,
//         golsVisitante: 0,
//         jogoId: i + 1,
//     });
// } 
// rodadaRepository.findAll()
//     .then((rodadas) => {
//         return rodadas[0];
//     })
//     .then((rodada) => {
//         return getRodadaByPalpites(usuario, rodada, palpites);
//     })
//     .then((apostaRodada) => {
//         return apostaRodadaRepository.save(apostaRodada);
//     })
//     .catch((erro) => {
//         console.log(`Não foi possível: ${erro.message}`);
//     })
// apostaRodadaRepository.findAll()
//     .then((apostas) => {
//         console.log(apostas[1].getUsuario().getNome())
//     })
// apostaRodadaRepository.findByNumeroRodada(1)
//     .then((apostasRodada) => {
//         console.log(apostasRodada[0].getUsuario().getNome())
//     })
// apostaRodadaRepository.findByUsuario("erik@email.com")
//     .then((aposta) => {
//         console.log(aposta)
//     });
// apostaRodadaRepository.findByNumeroRodadaEUsuario(1, "erik@email.com")
//     .then((aposta) => {
//         console.log(aposta)
//     })